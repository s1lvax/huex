"""huex: A powerful, lightweight CLI tool to control HUE LIGHTS in Conbee II."""
